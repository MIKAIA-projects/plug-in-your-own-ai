from dataclasses import dataclass, field
from dataclass_wizard import JSONWizard, JSONListWizard
from typing import List
#import json
import requests              
from PIL import Image
from io import BytesIO

 
@dataclass 
class PointF(JSONWizard):
    """PointF 2D point with floating point coordinates"""

    x: float = 0.0  
    """x-coordinate of the 2D point"""
    y: float = 0.0
    """y-coordinate of the 2D point"""
    
    def __str__(self):
        return 'x: {} y: {}'.format(self.x, self.y)

@dataclass 
class SizeF(JSONWizard):
    """SizeF 2D size with floating point dimensions"""

    width: float = 0.0
    """width"""
    height: float = 0.0
    """height"""
    
    def __str__(self):
        return 'w: {} h: {}'.format(self.width, self.height)

@dataclass 
class RectF(JSONWizard):
    """RectF 2D rectangle in floating point coordinates"""

    x: float = 0.0
    """x-coordinate of the top left corner"""
    y: float = 0.0
    """y-coordinate of top left corner"""
    width: float = 0.0
    """width of the rectangle"""
    height: float = 0.0
    """height of the rectangle"""
    
    def __str__(self):
        return 'x: {} y: {}  w: {} h: {}'.format(self.x, self.y, self.width, self.height)

@dataclass 
class KeyValuePair(JSONWizard):
    """RectF 2D rectangle in floating point coordinates"""

    key: str = ''
    """Key name"""
    value: str = ''
    """The value assigned to the key"""
    
    def __str__(self):
        return '{} = {}  w: {} h: {}'.format(self.key, self.value)

@dataclass 
class UserParameters(JSONWizard):
    """User defined parameters as key/value pairs"""

    data: List[KeyValuePair] = field(default_factory=list)
    """List of user defined parameters as key/value pairs"""
    
    def __str__(self):
        return 'User parameters: {} key/value pairs'.format(len(data))


@dataclass 
class Annotation(JSONWizard):
    """Annotation An MIKAIA annotation object(graphical shape)

    The following MIKAIA annotation objects are supported:
    'Point', 'Line', 'Rectangle', 'Ellipse', 'Polygon', 'PathWithHoles'
    """
    shapeType: str = ''
    """shape type of the annotation. Supported values: 'Point', 'Line', 'Rectangle', 'Ellipse', 'Polygon', 'PathWithHoles'"""

    coordinates: List[List[float]] = field(default_factory=list) 
    """Coordinates of the shape(outline and optional holes) as lists of 2D point coordinates.

    List of point lists where each point list is a flat array of 2D point coordinates(in 'µm')
    in the format [x1, y1, x2, y2, ... xn, yn].
    The 1st point lists contains the coordinates of the outline contour.
    All further point lists describe the contours of holes lying inside the outline.
    Holes are only relevant for shapeType 'PathWithHoles'.
    All other shapes types consist of exactly one point list with the following content:
    'Point': [x, y] the point coordinates.
    'Line': [x1, y1, x2, y2]' start point and end point of the line.
    'Rectangle': [x1, y1, x2, y2]' top left and bottom right coordinates of the rectangle.
    'Ellipse': [x1, y1, x2, y2]' top left and bottom right coordinates of the bounding rectangle.
    'Polygon': [x1, y1, ... xn, yn]' coordinates of n polygon points.
    """
    id: int = -1
    """MIKAIA-ID of the annotation. Never change this value!"""

    className: str = ''
    """Name of the associated annotation class"""
    
    def __str__(self):
        return '{}(shapeType={}, id={}, className={}, coordinate lists[{}])'.format(
                        self.__class__.__name__,
                        self.shapeType,
                        self.id,
                        self.className,
                        len(self.coordinates))
    
    # returns the annotation coordinates as a list of tuple lists:
    # [ [(x1, y1), (x2, y2), ... (xn, yn)], [(x1, y1), (x2, y2), ... (xm, ym)], ...]
    def toTuples(self):
        tupleLists = []
        for coord_list in self.coordinates:
            point_tuples = []
            for i in range(1, len(coord_list), 2):
                point_tuples.append((coord_list[i-1], coord_list[i]))
            tupleLists.append(point_tuples)
        return tupleLists

    # returns the annotation coordinates as lists of [x, y] arrays:
    # [ [[x1, y1], [x2, y2], ... [xn, yn]], [[x1, y1], [x2, y2], ... [xm, ym]], ...]
    def toArrays(self):
        pointArrays = []
        for coord_list in self.coordinates:
            point_array = []
            for i in range(1, len(coord_list), 2):
                point_array.append([coord_list[i-1], coord_list[i]])
            pointArrays.append(point_array)
        return pointArrays

    # returns the bounding rectangle of the annotation outline coordinates as RectF instance
    def boundingRect(self, index = 0):
        min_x = min_y = max_x = max_y = 0
        if index >= 0 and len(self.coordinates) > index and len(self.coordinates[index]) > 0:
            min_x = max_x = self.coordinates[index][0]
            min_y = max_y = self.coordinates[index][1]
            for i in range(1, len(self.coordinates[index]), 2):
                x = self.coordinates[index][i-1]
                y = self.coordinates[index][i]
                min_x = min(x, min_x)
                max_x = max(x, max_x)
                min_y = min(y, min_y)
                max_y = max(y, max_y)
        return RectF(min_x, min_y, max_x - min_x, max_y - min_y)
        
#@@dataclass 
#@class AnnotationList(JSONWizard):
#@    items: list[Annotation] = field(default_factory=list) 
    

@dataclass 
class AnnotationClass((JSONWizard)):
    className: str = ''
    classDescription: str = ''
    id: int = -1  # Internal class Id created by MIKAIA
    
    outlineWidth: int = -1 # Outline width(in screen pixels) for annotations associated with this annotation class
    outlineColor: str = '' # Outline color for annotations associated with this annotation class
    fillColor: str = ''    # Fill color for annotations associated with this annotation class
    opacity: float = 1.0   # Opacity for annotations associated with this annotation class(0.0(fully transparent) to 1.0(fully opaque))

    def __str__(self):
        return '{}(className="{}" description="{}" id={} outlineWidth={} outlineColor="{}" fillColor="{}" opacity="{:.3f}")'.format(
                        self.__class__.__name__,
                        self.className,
                        self.classDescription,
                        self.id,
                        self.outlineWidth,
                        self.outlineColor,
                        self.fillColor,
                        self.opacity)
    
#@dataclass 
#class AnnotationClassList(JSONWizard):
#    items: list[AnnotationClass] = field(default_factory=list) 

@dataclass 
class ChannelInfo(JSONWizard):
    name: str = ''
    type: str = ''  # supported values: 'Brightfield', 'Fluorescence', 'Other', 'Unspecified'
    index: int = -1
    
    def __str__(self):
        return '{}(type={}, name={}, index={})'.format(
                        self.__class__.__name__,
                        self.type,
                        self.name,
                        self.index)
 
@dataclass 
class SlideInfo(JSONWizard):
    name: str
    slideRect: RectF
    nativeResolution: SizeF
    roi: List[Annotation] = field(default_factory=list) 
    channels: List[ChannelInfo] = field(default_factory=list) 
    
    def __str__(self):
        return 'Slide name: {}\r\nSlide area: {} um\r\nNative resolution: {} um\r\nroi[{}]\r\nchannels[{}]'.format(
                    self.name, 
                    self.slideRect, 
                    self.nativeResolution,
                    len(self.roi),
                    len(self.channels))

@dataclass 
class ProgressInfo(JSONWizard):
    progressRatio: float = 1.0 # Progress info as value between 0.0(start of session) and 1.0(end of session)
    progressAmount: int = -1   # Progress as integer value(Use it when a 'progressRatio' value cannot be provided)
    message: str = ''          # Optional message text
    
    def __str__(self):
        return '{}(progressRatio={}, progressAmount={}, message={})'.format(
                        self.__class__.__name__,
                        self.progressRatio,
                        self.progressAmount,
                        self.message)
 


###############################################
## Python client for MIKAIA SlideService API ##
###############################################
class SlideService(object):
    def __init__(self, slidePath: str):
        self._rootPath = slidePath
        self._slideInfoPath = self._rootPath + "/slideInfo"
        self._thumbnailPath = self._rootPath + "/thumbnail"
        self._roiPath = self._rootPath + "/roi"
        self._nativeRoiPath = self._rootPath + "/nativeRoi"
        self._annoPath = self._rootPath + "/annotation"
        self._annoClassPath = self._rootPath + "/annotationClass"
        self._progressPath = self._rootPath + "/progress"
        self._userParamPath = self._rootPath + "/userParameter"
        self._annoShapeTypes = ['Point', 'Line', 'Rectangle', 'Ellipse', 'Polygon', 'PathWithHoles']
        self._requestCounter = 0
        self._lastRequest = None
        self._lastRequestParams = None
        self._lastResponse = None
        self._userParameters = None
        getUserParameters()
        
    def __str__(self):
        return '  Root path: {}\r\n  Request count: {}'.format(self._rootPath, self._requestCounter)
        
    # Send a GET request to the MIKAIA 'SlideService'        
    def _makeGetRequest(self, req_url, req_params, log = False):
        self._lastResponse = None
        self._lastRequest = req_url 
        self._lastRequestParams = req_params 
        if log:
            self.printLastRequest()
        self._requestCounter += 1   
        self._lastResponse = requests.get(req_url, params = req_params)
        if log:
            self.printLastResponse()
        return self._lastResponse

    # Send a POST request to the MIKAIA 'SlideService'        
    def _makePostRequest(self, req_url, data_to_post, log = False):
        self._lastResponse = None
        self._lastRequest = req_url 
        self._lastRequestParams = data_to_post 
        if log:
            self.printLastRequest()

        self._requestCounter += 1
        
        if issubclass(type(data_to_post), JSONWizard):
            json_data = data_to_post.to_json()
            self._lastResponse = requests.post(req_url, data=json_data)
        else:
            self._lastResponse = requests.post(req_url, data=data_to_post)

        if log:
            self.printLastResponse()
        return self._lastResponse

    # Send a PATCH request to the MIKAIA 'SlideService'        
    def _makePatchRequest(self, req_url, patch_data, log = False):
        self._lastResponse = None
        json_patch_data = self._patchDataToJson(patch_data)
        self._lastRequest = req_url 
        self._lastRequestParams = json_patch_data 
        if log:
            self.printLastRequest()

        self._requestCounter += 1   
        self._lastResponse = requests.patch(req_url, data=json_patch_data)

        if log:
            self.printLastResponse()
        return self._lastResponse

    def _patchDataToJson(self, patch_data):
        json_patch_data = '['
        for patch_item in patch_data:
            if len(patch_item) != 3:
               raise Exception(f'Insufficient patch data {patch_item} - three items required')
            if len(json_patch_data) > 1:
                json_patch_data += ' , '
            json_patch_data += '{ "op": "' + patch_item[0] + '", '
            json_patch_data += '"path": "' + patch_item[1] + '", '
            json_patch_data += '"value": "' + patch_item[2] + '" }'
        json_patch_data += ']'
        return json_patch_data


    # Print last request(url and parameters) sent to the MIKAIA 'SlideService'        
    def printLastRequest(self):
        print('Request url: {}'.format(self._lastRequest))
        print('Request params: {}'.format(self._lastRequestParams))
        
    # Print last response(status code and headers) received from the MIKAIA 'SlideService'        
    def printLastResponse(self):
        self._printResponse(self._lastResponse, "")
        
    def _printResponse(self, response, title):
        if title != None and len(title) > 0:
            print(title)
        print('Response - Statuscode: {}  {}'.format(response.status_code, response.reason))
        print('Response - Headers:')
        print(response.headers)
    
    # convert array of 2D points [[x1, y1], [x2, y2], .... [xn, yn]] to flat array of float values [x1, y1, x2, y2, .... xn, yn ]
    def _ptArray2FloatArray(self, pt_array):
        float_array = []
        for pt in pt_array:
            float_array += pt
        return float_array
    
    # Create a 'AnnotationClass' class instance from given parameters.
    # class_name: unique name that identifies the annotation class.
    # line_width_px: Outline width(in screen pixels) for annotations associated with this annotation class.
    # line_color: Outline color for annotations associated with this annotation class.
    #             RGB color definition as hexadecimal HTML '#AARRGGBB' string(e.g. '#ffc280de'). 
    # fill_color: Fill color for annotations associated with this annotation class.
    #             RGB color definition as hexadecimal HTML '#AARRGGBB' string(e.g. '#ffc280de').
    # Opacity for annotations associated with this annotation class(0.0(fully transparent) to 1.0(fully opaque))
    def createAnnotationClass(self, class_name, description = "",line_width_px = -1, line_color = "", fill_color = "", opacity = 1.0):
        annoClass = AnnotationClass(className=class_name, classDescription=description)
        annoClass.outlineWidth = line_width_px
        annoClass.outlineColor = line_color
        annoClass.fillColor = fill_color
        annoClass.opacity = opacity
        return annoClass
      
    # Create a 'Annotation' class instance from given parameters.
    # shape_type: string that identifies the shape type - one of {'Point', 'Line', 'Rectangle', 'Ellipse', 'Polygon', 'PathWithHoles'}
    # outline: annotation outline contour as 2D-coordinate list(slide scene coordinates in um) e.g. [[250.0, 300.0], [555.5, 300.0] ... [250.0, 800.0]] 
    # holes: hole contours as list of 2D-coordinate lists 
    # class_name: optional name of a annotation class to which the annotation should be assigned
    def createAnnotation(self, shape_type, outline, holes = [], class_name = ""):
        if shape_type not in self._annoShapeTypes:
            raise Exception("Unknown shapeType '" + shape_type + "'.")
        anno = Annotation(shapeType=shape_type, coordinates=[], className = class_name)
        anno.coordinates.append(self._ptArray2FloatArray(outline))
        for hole in holes:
            anno.coordinates.append(self._ptArray2FloatArray(hole))
        return anno   
    
    
    ###############################################
    ## MIKAIA 'SlideService' interface functions ##
    ###############################################
    
    # Get slide informations.
    def getSlideInfo(self, log = False):
        req_params = ""
        response = self._makeGetRequest(self._slideInfoPath, req_params, log)
        if (response.status_code == 200):
            slideInfo = SlideInfo.from_json(response.content)
            return slideInfo
        else:
            self._printResponse(response, "Unexpected response:")
        return None

    # Get slide informations.
    def getUserParameters(self, log = False):
        if self._userParameters is None:
            req_params = ""
            response = self._makeGetRequest(self._userParamPath, req_params, log)
            if (response.status_code == 200):
                self._userParameters = SlideInfo.from_json(response.content)
                return slideInfo
            else:
                self._printResponse(response, "Unexpected response:")
        key_value_map = {}
        if self._userParameters is not None:
            for item in self._userParameters.data:
                key_value_map[item.key] = item.value
        return key_value_map

    # Provide progress information.
    def sendProgress(self, ratio, amount = 0, message = "", log = False):
        progressInfo = ProgressInfo(progressRatio=ratio, progressAmount=amount, message = message)
        json_data = ProgressInfo.to_json(progressInfo)

        response = self._makePostRequest(self._progressPath, json_data, log)
        if (response.status_code != 200):
            self._printResponse(response, "Unexpected response:")

    # Provide a message.
    def sendMessage(self, message, log = False):
        self.sendProgress(-1.0, -1, message, log)

    # Get thumbnail image of the slide.
    # max_width: maximum width of the thumbnail image in pixels.
    # max_height: maximum height of the thumbnail image in pixels.
    def getThumbnail(self, max_width = 512, max_height = 512, log = False):
        req_params = {'max_width': max_width, 'max_height': max_height} 
        response = self._makeGetRequest(self._thumbnailPath, req_params, log)
        if (response.status_code == 200):
            thumb_img = Image.open(BytesIO(response.content))
            return thumb_img
        else:
            self._printResponse(response, "Unexpected response:")
        return None
        
    # Get a rectangular ROI of the slide as (PIL-)image.
    # x_um, y_um: location of the ROI(top left corner, in um).
    # w_um, h_um: width and height of the ROI in um.
    # px_width_um, px_height_um: desired pixel resolution of the returned ROI image in um/pixel.
    # px_format: pixel format of the  ROI image 'BGR', 'RGB' or 'Gray'.
    # channel_idx: index of a pixel color channel. Useful to extract a certain color channel of a fluorescence slide.
    #              Default is -1(use all channels).
    #              Available indices are listed in the channels[] array of the SlideInfo class that can be obtained by method getSlideInfo()
    def getROI(self, x_um, y_um, w_um, h_um, px_width_um, px_height_um = 0, px_format = 'BGR', channel_idx = -1, log = False):
        if px_height_um == 0:
            px_height_um = px_width_um
        req_params = {'x': x_um, 'y': y_um, 'w': w_um, 'h': h_um, 'px_width_um': px_width_um, 'px_height_um': px_height_um, 'px_format': px_format, 'channel_idx': channel_idx}
        response = self._makeGetRequest(self._roiPath, req_params, log)
        if (response.status_code == 200):
            thumb_img = Image.open(BytesIO(response.content))
            return thumb_img
        else:
            self._printResponse(response, "Unexpected response:")
        return None

    # Get a rectangular ROI of the slide as (PIL-)image.
    # The returned image has the native slide pixel resolution(as returned from getSlideInfo())
    # x_um, y_um: location of the ROI(top left corner, in um).
    # w_px, h_px: width and height of the ROI image in pixels.
    # w_px, h_px: width and height of the ROI image in pixels.
    # px_format: pixel format of the  ROI image 'BGR', 'RGB' or 'Gray'.
    # channel_idx: index of a pixel color channel. Useful to extract a certain color channel of a fluorescence slide.
    #              Default is -1(use all channels).
    #              Available indices are listed in the channels[] array of the SlideInfo class that can be obtained by method getSlideInfo()
    def getNativeROI(self, x_um, y_um, w_px, h_px, px_format = 'BGR', channel_idx = -1, log = False):
        req_params = {'x': x_um, 'y': y_um, 'w': w_px, 'h': h_px, 'px_format': px_format, 'channel_idx': channel_idx}
        response = self._makeGetRequest(self._nativeRoiPath, req_params, log)
        if (response.status_code == 200):
            thumb_img = Image.open(BytesIO(response.content))
            return thumb_img
        else:
            self._printResponse(response, "Unexpected response:")
        return None


    # Get a list of annotation items(see class Annotation) from the slide.
    # shape_type: if provided, only annotations of the specified shape type are returned.
    # class_name: if provided, only annotations which belong to the specified annotation class are returned.
    # Returns a array of 'class Annotation' items.
    def getAnnotations(self, shape_type = "", class_name = "", log = False):
        #class_name = class_name.replace(" ", "%20")
        req_params = {'shape_type': shape_type, 'class_name': class_name}
        response = self._makeGetRequest(self._annoPath, req_params, log)
        if (response.status_code == 200):
            annoList = Annotation.from_json(response.content)
            return annoList
        else:
            self._printResponse(response, "Unexpected response:")
        return []

    # Create a 'Annotation' instance from given parameters and add it to the slide.
    # shape_type: string that identifies the shape type - one of {'Point', 'Line', 'Rectangle', 'Ellipse'. 'Polygon'}
    # outline: annotation outline contour as 2D-coordinate list(slide scene coordinates in um) e.g. [[250.0, 300.0], [555.5, 300.0] ... [250.0, 800.0]] 
    # holes: hole contours as list of 2D-coordinate lists 
    # class_name: optional name of a annotation class to which the annotation should be assigned.
    #             If a class_name is provided and such a annotation class doesn't exist,
    #             a new annotation class with this name will be created automatically.
    def addAnnotation(self, shape_type, outline, holes, class_name = "", log = False):
        anno = self.createAnnotation(shape_type, outline, holes, class_name)
        ret = self.addAnnotations([anno], log)
        if ret != None:
            ret = ret[0]
        return ret

    # Add one or more annotation objects(of class Annotation) to the slide.
    # annotations: list of annotation objects of type 'Annotation'.
    # Note 1: Use method createAnnotation() to create instances of class 'Annotation'.
    # Note 2: if the className member of an annotation is set and such a annotation class doesn't exist,
    #         a new annotation class with this name will be created automatically.
    def addAnnotations(self, annotations, log = False):
        if not isinstance(annotations, list):
            raise Exception("Parameter 'annotations' shall be a list of instances of class Annotation.")
        for anno in annotations:
            if not isinstance(anno, Annotation):
                raise Exception("'annotations' list contains item(s) that are not instances of class Annotation.")
            if anno.shapeType not in self._annoShapeTypes:
                raise Exception("'annotations' list contains item(s) with unknown shapeType '" + anno.shapeType + "'.")
            
        json_data = Annotation.list_to_json(annotations)

        response = self._makePostRequest(self._annoPath, json_data, log)
        if (response.status_code == 200):
            anno_list_response = Annotation.from_json(response.content)
            for i in range(len(anno_list_response)):
                annotations[i].id = anno_list_response[i].id
                annotations[i].className = anno_list_response[i].className
            return annotations
        else:
            self._printResponse(response, "Unexpected response:")
        return None
        
    # Updates the content of an already existing annotation item(see class Annotation).
    # Currently only the 'className' is supported by this update operation.
    # annotation: an annotation object of type 'Annotation'.
    def updateAnnotation(self, annotation, log = False):
        if not isinstance(annotation, Annotation):
            raise Exception("Given annotation item isn't an instance of class Annotation.")
        
        # provide data to update(currently only the 'className' is supported)     
        patch_data = []
        patch_item = ['replace', 'className', annotation.className ]
        patch_data.append(patch_item)
        
        request_path = self._annoPath + '/' + str(annotation.id)
        response = self._makePatchRequest(request_path, patch_data, log)
        if (response.status_code == 200):
            return True
        else:
            self._printResponse(response, "Unexpected response:")
        return False

    # Get a list of all annotation class items(see class AnnotationClass) of the slide.
    def getAnnotationClasses(self, log = False):
        req_params = ""
        response = self._makeGetRequest(self._annoClassPath, req_params, log)
        if (response.status_code == 200):
            annoClassList = AnnotationClass.from_json(response.content)
            return annoClassList
        else:
            self._printResponse(response, "Unexpected response:")
        return []

    # Adds an annotation class to the slide.
    # class_name: unique name of the annotation class.
    # description: optional description of the annotation class.
    # line_color: Outline color for annotations associated with this annotation class.
    #             RGB color definition as hexadecimal HTML '#AARRGGBB' string(e.g. '#ffc280de'). 
    # fill_color: Fill color for annotations associated with this annotation class.
    #             RGB color definition as hexadecimal HTML '#AARRGGBB' string(e.g. '#ffc280de'). 
    # Opacity for annotations associated with this annotation class(0.0(transparent) to 1.0(full opaque))
    def addAnnotationClass(self, class_name, description = "", line_width_px = -1, line_color = "", fill_color = "", opacity = 1.0, log = False):
        annotationClass = self.createAnnotationClass(class_name, description, line_width_px, line_color, fill_color, opacity)
        ret = self.addAnnotationClasses([annotationClass], log)
        if ret != None:
            ret = ret[0]
        return ret

    # Adds one or more annotation class objects(of class AnnotationClass) to the slide.
    # anno_classes: list of annotation class objects of type 'AnnotationClass'.
    # Note 1: Use method createAnnotationClass() to create instances of class 'AnnotationClass'.
    def addAnnotationClasses(self, anno_classes, log = False):
        if not isinstance(anno_classes, list):
            raise Exception("Parameter 'anno_classes' shall be a list of instances of class AnnotationClass.")
        for anno_class in anno_classes:
            if not isinstance(anno_class, AnnotationClass):
                raise Exception("'anno_classes' list contains items which are not instances of class AnnotationClass.")
        
        json_data = AnnotationClass.list_to_json(anno_classes)

        response = self._makePostRequest(self._annoClassPath, json_data, log)
        if (response.status_code == 200):
            anno_class_list_response = AnnotationClass.from_json(response.content)
            for i in range(len(anno_class_list_response)):
                anno_classes[i].className = anno_class_list_response[i].className
                anno_classes[i].classDescription = anno_class_list_response[i].classDescription
                anno_classes[i].id = anno_class_list_response[i].id
                anno_classes[i].outlineWidth = anno_class_list_response[i].outlineWidth
                anno_classes[i].outlineColor = anno_class_list_response[i].outlineColor
                anno_classes[i].fillColor = anno_class_list_response[i].fillColor
                anno_classes[i].opacity = anno_class_list_response[i].opacity
            return anno_classes
        else:
            self._printResponse(response, "Unexpected response:")
        return None

    # Updates the content of an already existing annotation class item(see class AnnotationClass).
    # Currently the following attributes of class AnnotationClass are supported:
    # - classDescription
    # - outlineWidth
    # - outlineColor
    # - fillColor
    # - opacity
    # annotation_class: an annotation_class object of type 'AnnotationClass'.
    def updateAnnotationClass(self, annotation_class, log = False):
        if not isinstance(annotation_class, AnnotationClass):
            raise Exception("Parameter 'annotation_class' isn't an instance of class AnnotationClass.")
        
        # provide data to update supported attributes     
        patch_data = []
        patch_item = ['replace', 'classDescription', annotation_class.classDescription ]
        patch_data.append(patch_item)
        if annotation_class.outlineWidth >= 0:
            patch_item = ['replace', 'outlineWidth', str(annotation_class.outlineWidth) ]
            patch_data.append(patch_item)
        patch_item = ['replace', 'outlineColor', annotation_class.outlineColor ]
        patch_data.append(patch_item)
        patch_item = ['replace', 'fillColor', annotation_class.fillColor ]
        patch_data.append(patch_item)
        if annotation_class.outlineWidth >= 0:
            patch_item = ['replace', 'opacity', '{:.3f}'.format(annotation_class.opacity) ]
            patch_data.append(patch_item)
        
        request_path = self._annoClassPath + '/' + str(annotation_class.id)
        response = self._makePatchRequest(request_path, patch_data, log)
        if (response.status_code == 200):
            return True
        else:
            self._printResponse(response, "Unexpected response:")
        return False




