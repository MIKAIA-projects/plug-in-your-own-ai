#!/bin/bash

script_file=$1
slide_service_path=$2
ret_code=0
special_ret_code=100

# activate virtual python environment
# place here the full path to your virtual python environment if the 'mikaia_plugin_api' package has been installed to an virtual python environment
# or comment it out, if the 'mikaia_plugin_api' package has been installed to your regular python installation
# source /full/path/to/your/virtual/python/environment/bin/activate
source /home/poi/Desktop/Python/mikaia_venv/bin/activate


# If no arguments are passed we start the MIKAIA Script Service
if [ "$script_file" == "" ] && [ "$slide_service_path" == "" ]; then
    echo "[INFO] Starting MIKAIA Script Service..."
    python3 -m mikaia_plugin_api.script_service_server
    ret_code=$?
    exit $ret_code
fi

# Check whether two arguments are passed
if [ "$script_file" == "" ]; then
    echo "[ERROR] Missing argument 1: <script_file>)"
    ret_code=2
    exit $ret_code
fi
if [ "$slide_service_path" == "" ]; then
    echo "[ERROR] Missing argument 1: <slide_service_path>)"
    ret_code=2
    exit $ret_code
fi

# Start MIKAIA Python Console or execute a MIKAIA Python Script
if [ "$script_file" = "MIKAIA Python Console" ]; then
    echo "[INFO] Open MIKAIA Python Console(SlideServicePath: $slide_service_path)"
    python3 -i -m mikaia_plugin_api.console ${slide_service_path}
    ret_code=$?
else
    echo "[INFO] Run MIKAIA Python Script '${script_file}' (SlideServicePath: $slide_service_path)"
    python3 ${script_file} ${slide_service_path}
    ret_code=$?  
fi

# By default we wait for user input to exit the terminal window.
# Except the MIKAIA python script returns the special code 100 which means: 
# Everythig Ok, but don't wait for user input to exit the terminal window.
if [[ $ret_code -ne $special_ret_code ]]; then
   read -rsn1 -p"Press any key to terminate... Exit code: $ret_code"
fi

exit $ret_code
