#!/usr/bin/env python3
import os
import sys
import platform
import pkg_resources
from .. import mikaia_api

def print_python_environment():
    if sys.prefix != sys.base_prefix:
        print('Python environment: ' + sys.prefix + '  based on  ' + sys.base_prefix)
    else:
        print('Python environment: ' + sys.prefix)
    
def console():
    pkg_version = pkg_resources.get_distribution('mikaia_plugin_api').version
    console_title = 'MIKAIA Slide Service Console({})'.format(pkg_version);
    system = platform.system().upper()
    if system == "LINUX":
        print(f"\x1B]0;{console_title}\x07") # set title of terminal window
    else:
        os.system('title ' + console_title) # set title of console window

    print('Starting {}...'.format(console_title))
    print_python_environment()

    ss = None
    slide_info = None
    slideServicePath = ''
    if len(sys.argv) <= 1:
        warning = 'WARNING - Slide Service Console: missing root path for Slide Service!'
        print('\x1b[1;33;41m' + warning)
        print('slideServicePath: not available - shall be passed as argument.' + '\x1b[0m')
        return ss

    slideServicePath = sys.argv[1]
      
    print(f'Root path for MIKAIA Slide Service: slideServicePath = "{slideServicePath}"')
    print('Creating SlideService object "ss"...')
    try:
        ss = mikaia_api.SlideService(slideServicePath)
        slide_info = ss.getSlideInfo()
    except Exception as e:
        warning = 'WARNING - Slide Service Console: invalid root path for MIKAIA Slide Service!'
        print('\x1b[1;33;41m' + warning)
        print(f'slideServicePath = "{slideServicePath}"' + '\x1b[0m')
        return ss
    
    print('\x1b[1;42m' + f'slideServicePath: "{slideServicePath}"')
    print(f'ss:\r\n{ss}')
    print(f'slide_info:\r\n{slide_info}' + '\x1b[0m')
    print()
    print(f'Now you can use the "ss" SlideService object - a few samples:')
    print(f'slide_info = ss.getSlideInfo()')
    print(f'thumb = ss.getThumbnail(800, 600)')
    print(f'anno_list = ss.getAnnotations()')
    print(f'anno_class_list = ss.getAnnotationClasses()')
    print(f'roi = ss.getROI(15000.5, 6000, 4000.0, 3000.0, 4.0, 4.0)')
    print(f'native_roi = ss.getNativeROI(17500.0, 7000, 1200, 1000)')
    print(f'rect_anno = ss.createAnnotation("Rectangle", [[5000.0, 4000.0], [9500.0, 7500.0]])')
    print(f'rect_anno.className = "MyClass1"')
    print(f'ellipse_anno = ss.createAnnotation("Ellipse", [[10000.0, 6000.0], [13500.0, 9500.0]])')
    print(f'ellipse_anno.className = "MyClass2"')
    print(f'ss.addAnnotations([rect_anno, ellipse_anno])')
    print(f'annoClass = ss.addAnnotationClass("MyClass3", "Annotation class just for test purposes")')
    print(f'rect_anno.className = "MyClass3"')
    print(f'ss.updateAnnotation(rect_anno)')
    print()
    return ss

if __name__ == '__main__':
    ss = console()
