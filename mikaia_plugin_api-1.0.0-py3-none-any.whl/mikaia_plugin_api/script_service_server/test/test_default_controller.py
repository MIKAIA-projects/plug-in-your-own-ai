# coding: utf-8

from __future__ import absolute_import
import unittest

from flask import json
from six import BytesIO

from mikaia_plugin_api.script_service_server.models.script_execution_info import ScriptExecutionInfo  # noqa: E501
from mikaia_plugin_api.script_service_server.models.script_info import ScriptInfo  # noqa: E501
from mikaia_plugin_api.script_service_server.test import BaseTestCase


class TestDefaultController(BaseTestCase):
    """DefaultController integration test stubs"""

    def test_execute_get(self):
        """Test case for execute_get

        Get execution state of a script
        """
        query_string = [('script_execution_id', 'MyMikaiaScript-34901')]
        headers = { 
            'Accept': 'text/plain',
        }
        response = self.client.open(
            '/MIKAIA/ScriptService/v1/execute',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_execute_post(self):
        """Test case for execute_post

        Execute a script
        """
        script_execution_info = {"slide_id":"slide_id","script_name":"script_name","slide_service_server":"http://192.168.178.26:9980/MIKAIA/SlideService/v1"}
        query_string = [('script_name', 'script_name_example')]
        headers = { 
            'Accept': 'text/plain',
            'Content-Type': 'application/json',
        }
        response = self.client.open(
            '/MIKAIA/ScriptService/v1/execute',
            method='POST',
            headers=headers,
            data=json.dumps(script_execution_info),
            content_type='application/json',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_scripts_get(self):
        """Test case for scripts_get

        Returns a list of available srcipts/applications
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/MIKAIA/ScriptService/v1/scripts',
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
