#!/usr/bin/env python3
import os
import sys
import socket
import connexion
import pkg_resources

from mikaia_plugin_api.script_service_server import encoder

def print_python_environment():
    if sys.prefix != sys.base_prefix:
        print('Python environment: ' + sys.prefix + '  based on  ' + sys.base_prefix)
    else:
        print('Python environment: ' + sys.prefix)
    
    working_dir = os. getcwd()
    print('Working directory: ' + working_dir)
    
    install_directory = os.path.dirname(os.path.abspath(sys.argv[0]))
    # print('Install directory: ' + install_directory)


def get_free_port():
    for port in range(9970, 9980):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1.0)
            inUse = (s.connect_ex(('localhost', port)) == 0)
            s.close()
            if not inUse:
                return port
                
    raise Exception("No free TCP/IP port available - all ports from 9970 to 9979 in use.")
    
def main():
    pkg_version = pkg_resources.get_distribution('mikaia_plugin_api').version
    print('Starting MIKAIA Script Service({})...'.format(pkg_version))
    print('arguments:')
    for arg in sys.argv:
        print('    ' + arg)

    if len(sys.argv) > 1:
       if os.path.isdir(sys.argv[1]):
            os.chdir(sys.argv[1])

    print_python_environment()

    tcp_port = get_free_port()
    
    app = connexion.App(__name__, specification_dir='./openapi/')
    app.app.json_encoder = encoder.JSONEncoder
    app.add_api('openapi.yaml',
                arguments={'title': 'MIKAIA Script Service'},
                pythonic_params=True)

    app.run(port=tcp_port)


if __name__ == '__main__':
    main()
