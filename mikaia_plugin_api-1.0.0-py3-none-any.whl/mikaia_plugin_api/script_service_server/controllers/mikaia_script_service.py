import os
import platform
import glob
import subprocess
import pkg_resources
from mikaia_plugin_api import mikaia_api


s_pythonConsoleAliasName = "MIKAIA Python Console"


class ScriptService(object):
    def __init__(self, wildcard: str):
        self._system = platform.system().upper()
        self._workingDir = os.getcwd()
        self._wildcard = wildcard
        self._execScript = ""
        self._processCounter = 0
        self._runningScripts = {}  # dictionary <string, subprocess>

        # set title of console window
        pkg_version = pkg_resources.get_distribution('mikaia_plugin_api').version
        console_title = 'MIKAIA Script Service({})  {}  {}'.format(pkg_version, self._workingDir, self._wildcard)
        
        # select execution script depending on operation system
        sourceFilePath = os.path.dirname(os.path.abspath(mikaia_api.__file__))
        #sourceFilePath = os.path.dirname(os.path.abspath(__file__))
        if self._system == "LINUX":
            print(f"\x1B]0;{console_title}\x07") # set title of terminal window
            self._execScript = os.path.realpath(sourceFilePath + '/scripts/Linux/runScript.sh')
        else:
            os.system('title ' + console_title) # set title of console window
            self._execScript = os.path.realpath(sourceFilePath + '/scripts/Windows/runScript.bat')

        # check existence of batch file 'runScript.bat'/'runScript.sh' that is required to start the script
        self._execScript
        if not os.path.isfile(self._execScript):
            msg = f"Missing required execution script: '{self._execScript}'"
            raise Exception(msg)
 
        print('MIKAIA ScriptService - running on {} system'.format(self._system))
        # print('Execution script: {}'.format(self._execScript))
        self.getScriptFileNames(True)
        
    def __str__(self):
        return '  Working directory: {}\r\n  wildcard: {}'.format(self._workingDir, self._wildcard)
        
    
    ################################################
    ## MIKAIA 'ScriptService' interface functions ##
    ################################################
    
    # Return list of files which match the specified wildcard pattern.
    def getScriptFileNames(self, log = False):
        file_names = glob.glob(self._wildcard) # get files which match the specified wildcard pattern.
        file_names.append(s_pythonConsoleAliasName) # Append an entry for the 'MIKAIA Python Console'

        if log:
            print('getScriptFileNames()')
            print('Working directory: {}'.format(self._workingDir))
            print('Wildcard: {}'.format(self._wildcard))
            print('Files:')
            print(file_names)
        return file_names


    # Executes a Mikaia script file.
    # script_name: name of the script file.
    # slide_server_path: path of the MIKAIA SlideServer REST API.
    # session_id: MIKAIA SlideServer session id
    # returns tuple (success, msg) where
    # success: True or False
    # msg: script execution id on success, error message otherwise
    def executeScript(self, script_name, slide_server_path, session_id, log = False):
        if log:
            print('executeScript({}, {}, {})'.format(script_name, slide_server_path, session_id))
        
        # check existence of the given script file
        script_file_path = self._workingDir + '/' + script_name
        if script_name != s_pythonConsoleAliasName:
            if not os.path.isfile(script_file_path):
                msg = f"Script file doesn't exist: '{script_name}'"
                return False, msg

        # check existence of batch file 'runScript.bat'/'runScript.sh' that is required to start the script
        execScriptFilePath = self._execScript
        if not os.path.isfile(execScriptFilePath):
            msg = f"Missing required execution script: '{self._execScript}'"
            return False, msg
        
        # try to start script execution
        success = True
        try:
            self._processCounter += 1
            script_execution_id = script_name + "_" + f"{self._processCounter:05d}"
            slideServiceRootPath = slide_server_path + "/" + session_id
            process = None
            creation_flags = None
            args = []
            
            # Start script on Windows system (in cmd.exe console)
            if self._system == "WINDOWS":
                
                args = ["cmd.exe", "/C", execScriptFilePath, script_name, slideServiceRootPath]
                creation_flags = subprocess.CREATE_NEW_CONSOLE
                process = subprocess.Popen(args, creationflags=subprocess.CREATE_NEW_CONSOLE)
            # Start script on LINUX system (in gnome-terminal)
            elif self._system == "LINUX":
                cmd = f"source {execScriptFilePath} '{script_name}' {slideServiceRootPath}"
                #args = ['xterm', '-e', cmd]
                args = ['gnome-terminal', '--wait', '--', 'bash', '-c', cmd]
                process = subprocess.Popen(args)
                #process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
            else:
                msg = f"MIKAIA ScriptService - unsupported system: {self._system}"
                print(msg)
                return False, msg
            
            print(f"Starting process [{script_execution_id}]: {args}")
            self._runningScripts[script_execution_id] = process
            msg = script_execution_id
            print("Done!")
            
        except FileNotFoundError:
            success = False
            msg = f"Failed to start script {script_name}"
        except Exception as e:
            success = False
            msg = f"Failed to start script {script_name}: {e}"

        if log:
            print('executeScript({}) returns: ({}, {})'.format(args, success, msg))
            
        return success, msg
        

    # Returns the execution status of a Mikaia script file.
    # script_execution_id: execution id of the script(returned form executeScript() call).
    # returns tuple (success, status, return_code) where
    # success: True or False
    # status: "RUNNING" or "FINISHED" on success, error message otherwise
    # return_code: script exit code on success, None otherwise
    def getScriptExecutionStatus(self, script_execution_id, log = False):
        if log:
            print('getScriptExecutionStatus({})'.format(script_execution_id))
        
        success = False
        status = ""
        return_code = None
        
        if script_execution_id not in self._runningScripts:
            status = f"No entry found for script execution id '{script_execution_id}'"
        else:
            success = True
            status = "RUNNING"
            process = self._runningScripts[script_execution_id]
            return_code = process.poll()
            
            if return_code is not None:
                status = "FINISHED"

        if log or status == "FINISHED":
            print('getScriptExecutionStatus({}) returns: ({}, {}, {},)'.format(script_execution_id, success, status, return_code))
            
        return success, status, return_code
        




