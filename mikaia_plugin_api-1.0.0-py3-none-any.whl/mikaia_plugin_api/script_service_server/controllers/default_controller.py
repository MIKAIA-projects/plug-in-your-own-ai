import connexion
import six
from typing import Dict
from typing import Tuple
from typing import Union

from mikaia_plugin_api.script_service_server.controllers.mikaia_script_service import ScriptService
from mikaia_plugin_api.script_service_server.models.script_execution_info import ScriptExecutionInfo  # noqa: E501
from mikaia_plugin_api.script_service_server.models.script_info import ScriptInfo  # noqa: E501
from mikaia_plugin_api.script_service_server import util



ss=ScriptService('*.py')


def execute_get(script_execution_id):  # noqa: E501
    """Get execution state of a script

    Returns the current execution state of a script/application started by the POST command # noqa: E501

    :param script_execution_id: The execution Id of the script. This Id is obtained in response to a POST command(that starts the execution of a script/application).
    :type script_execution_id: str

    :rtype: Union[str, Tuple[str, int], Tuple[str, int, Dict[str, str]]
    """
    result_tuple = ss.getScriptExecutionStatus(script_execution_id, False)
    
    http_code = 200
    if result_tuple[0] == False:
        http_code = 500
    return result_tuple[1], http_code


#def execute_post(script_name, script_execution_info):  # noqa: E501
def execute_post(script_name):  # noqa: E501
    """Execute a script

    Starts the execution of the specified script/application # noqa: E501

    :param script_name: Name of the script/application to be executed.
    :type script_name: str
    :param script_execution_info: data needed to start a MIKAIA script
    :type script_execution_info: dict | bytes

    :rtype: Union[str, Tuple[str, int], Tuple[str, int, Dict[str, str]]
    """
    #if connexion.request.is_json:
    script_execution_info = ScriptExecutionInfo.from_dict(connexion.request.get_json())  # noqa: E501
    
    slide_service_path = script_execution_info.slide_service_server
    session_id = script_execution_info.slide_id
    result_tuple = ss.executeScript(script_name, slide_service_path, session_id, True)
    
    http_code = 200
    if result_tuple[0] == False:
        http_code = 500
    return result_tuple[1], http_code


def scripts_get():  # noqa: E501
    """Returns a list of available srcipts/applications

    Returns a list of all available srcipts/applications which use the MIKAIA OpenAPI interface &#39;SlideInterface&#39; # noqa: E501


    :rtype: Union[List[ScriptInfo], Tuple[List[ScriptInfo], int], Tuple[List[ScriptInfo], int, Dict[str, str]]
    """
    file_names = ss.getScriptFileNames(True)
    script_list = [ScriptInfo(file, "") for file in file_names]
    return script_list, 200
